Ethan Tarnarider
2365982
tarnarider@chapman.edu
PA5
To compile: g++ -c Student.cpp Database.cpp Faculty.cpp Main.cpp
To create object files: g++ -o *executable name* Student.cpp Database.cpp Faculty.cpp Main.cpp
To run: ./*executable name*
The only issues are that some of the functionality of the menu does not work due to the tree not being balanced and that you cannot print faculty information more than once