#include "Database.h"

int main()
{
    Database d;
    d.driverCode();
    return 0;
}
