Ethan Tarnarider
CPSC 350-03
tarnarider@chapman.edu
2365982
No errors
To compile: g++ -c main.cpp WGraph.cpp
To make object files g++ -o *executable name* main.cpp WGraph.cpp
To run: ./*executable name* *input file name*