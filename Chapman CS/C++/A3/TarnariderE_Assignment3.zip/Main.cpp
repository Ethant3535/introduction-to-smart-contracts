#include "Speakerview.h"

int main(int argc, char const *argv[])
{
    Speakerview s;
    s.mainFunction(argv[1]);
    return 0;
}
