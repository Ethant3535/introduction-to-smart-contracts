#include "Simulation.h"

int main(int argc, char** argv)
{
    Simulation s;
    s.runTheSimulation(argv[1]);
    return 0;
}
