#include "Window.h"


Window::~Window(){}
Window::Window(){
        c=NULL;
        endTime=-1;
        int idleTime=0;
    }