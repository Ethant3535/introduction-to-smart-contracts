Ethan Tarnarider
2365982
tarnarider@chapman.edu
PA4
To compile: g++ -c *included files*
To make object files: g++ -c *executable name* *included files*
To run: ./*executable name* *input file name*
Throws a handful of warnings when you compile it but they do not cause any issues that I have found