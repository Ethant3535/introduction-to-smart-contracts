import java.util.LinkedList;
public class Track {
    String m_trackType;
    String m_trackName;
    String m_artist;
    int m_timesPlayed;
    
    public String getTrackType() {
        return m_trackType;
      }    
    public void setTrackType(String trackType) {
        m_trackType = trackType;
      }
    public String getTrackName() {
        return m_trackName;
      }    
    public void setTrackName(String trackName) {
        m_trackName = trackName;
      }
    public String getArtist() {
        return m_artist;
      }    
    public void setArtist(String artist) {
        m_artist = artist;
      }
    public String getTimesPlayed() {
        return m_timesPlayed;
      }    
    public void setTimesPlayed(int timesPlayed) {
        m_timesPlayed = timesPlayed;
      }
    
}
