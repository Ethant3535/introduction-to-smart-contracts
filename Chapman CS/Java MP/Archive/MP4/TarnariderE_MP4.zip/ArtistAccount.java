public class ArtistAccount extends Account {
    String m_name;
    public ArtistAccount(Name artistName){
        m_name=artistName;
    }
}
